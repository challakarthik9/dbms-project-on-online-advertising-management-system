## Ad-Man
Front-End for AdMan (DBMS Project)

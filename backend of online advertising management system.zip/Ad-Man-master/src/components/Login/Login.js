import React, { Component } from 'react';
import { Divider,Button, Icon, Input } from 'semantic-ui-react'
import './Login.css'
import '../Main/Main'
import Main from '../Main/Main';



class Login extends Component{
    constructor(){
        super()
        this.state = {
            Email: '',
            Password: '',
            showError: false,
            loggedIn : false
        }
    }

    onEmailChange = (event) => {
        this.setState({Email: event.target.value})
    }

    onPasswordChange = (event) => {
        this.setState({Password: event.target.value})
    }

    submitDetails = () => {
        fetch('http://localhost:5000/signin',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                Email: this.state.Email,
                Password: this.state.Password
            })
        })
        .then(response => response.json())
        .then( data => {
            if (data=== 'succ') {
                console.log('Signed in')
                this.setState({loggedIn: true})
            }
            else {
                this.setState({showError: true})
            }
        })
    }

    render(){
        if (this.state.loggedIn === true) {
            return(
                <Main email={this.state.Email}/>
            );
        }
        else {
        return(
            <div className='dib shadow-1 pa4 mt6'>
                <p className='fw6 f4'>Login</p>
                <Input iconPosition='left' placeholder='Email' onChange={this.onEmailChange}>
                <Icon name='at' />
                <input />
                </Input>
                <br/>
                <Input className='mv3' iconPosition='left' placeholder='Password' type='password' onChange={this.onPasswordChange}>
                <Icon name='lock' />
                <input />
                </Input>
                <br/>
                { this.state.showError ? <div className='fw4 f6 mb3 red'>Email or Password is incorrect</div> : null}
                <Button basic color='blue' content='Login' onClick = {this.submitDetails}
                />
                <Divider horizontal className='divider-login'>Or</Divider>
                <Button href='/signup' color='blue'>Sign Up</Button>
                <br/>
                <div className='mt3 '><a>Forgot Password?</a></div>           
            </div>
        );
    }
    }
}

export default Login;

import React, { Component } from 'react';
import { Button, Input, Icon, Message} from 'semantic-ui-react';

class Profile extends Component{
    constructor(props){
        super(props)
        this.state={
            buttonEnable: false,
            FirstName: this.props.firstname,
            LastName: this.props.lastname,
            Email: this.props.email,
            PhoneNumber : this.props.phonenumber,
            AccID: this.props.accid,
            showSuccess: false

        }
    }
    updateProfile = () => {
        console.log(this.state)
        fetch('http://localhost:5000/updateprofile',{
            method: 'put',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                Email: this.state.Email,
                FirstName: this.state.FirstName,
                LastName : this.state.LastName,
                PhoneNumber: this.state.PhoneNumber,
                AccId : this.state.AccID
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data==='updated'){
                this.setState({showSuccess: true})
            }
        })
    }

    onFirstNameChange = (event) => {
        this.setState({FirstName:event.target.value,buttonEnable: true})
        console.log(event.target.value)
    }

    onLastNameChange = (event) => {
        this.setState({LastName:event.target.value,buttonEnable: true})
        console.log(event.target.value)
    }

    onEmailChange = (event) => {
        this.setState({Email:event.target.value,buttonEnable: true})
        console.log(event.target.value)
    }
    onPhoneNumberChange = (event) => {
        this.setState({PhoneNumber:event.target.value,buttonEnable: true})
        console.log(event.target.value)
    }


    render(){
        return(
            <div className='dib shadow-1 pa4 ma6'>
            <h3>Your Profile</h3>
            <div className='dib mr3'>
                        <Input placeholder='First Name' defaultValue={this.props.firstname} onChange={this.onFirstNameChange}>
                        <input />
                        </Input>
                </div>

                <div  className='dib'>
                    <Input placeholder='Last Name' defaultValue={this.props.lastname} onChange={this.onLastNameChange}>
                    <input />
                    </Input>
                </div>

                <Input className='mt3' 
                    fluid iconPosition='left' 
                    placeholder='Email Address'>
                    <Icon name='at' />
                    <input defaultValue={this.props.email} onChange={this.onEmailChange}/>    
                </Input>

                <Input 
                    className='mt3' 
                    fluid iconPosition='left' 
                    type='number' placeholder='Phone Number'>
                    <Icon name='phone' />
                    <input defaultValue={this.props.phonenumber} onChange={this.onPhoneNumberChange}/>
                </Input>
                {this.state.showSuccess ? <Message success header='Updated!' content="Your details have been saved succesfully" /> : null}
                <div className='mv3'><a href='/profile'>Change password</a></div>
                <Button color='blue' fluid disabled={!this.state.buttonEnable}
                    className='ma4' 
                    onClick={() => {this.updateProfile()}}>Save changes
                </Button>
            </div>
        );
    }
}

export default Profile
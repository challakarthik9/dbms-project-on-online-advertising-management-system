import React, { Component } from 'react';
import { Card, Button } from 'semantic-ui-react'

class PlatformCards extends Component{

    deletePlatform(){
        const PID = this.props.platformid

        fetch('http://localhost:5000/deleteplatform',{
            method: 'put',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                PID : PID
            })
        })
        .then(response => response.json())
        .then(data => {
            this.props.refresh()
        })
    }

    render(){
        return(
            <Card>
                <Card.Content>
                <Card.Header content={this.props.name} />
                <Card.Meta content={this.props.url}/>
                <Card.Description content={this.props.type}/>
                </Card.Content>
                <Card.Content extra>
                    <div>
                    <Button basic color='red' onClick={() => this.deletePlatform()}>
                        Delete Platform
                    </Button>
                    </div>
                </Card.Content>
            </Card>
        );
    }
}

export default PlatformCards;
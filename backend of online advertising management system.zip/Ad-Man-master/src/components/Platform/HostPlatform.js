import React, { Component } from 'react';
import { Input, Icon, Button, Checkbox, Dropdown, Message} from 'semantic-ui-react'


const Options = [ { key: 'Website', value: 'Website', flag: 'Website', text: 'Website' },
                    { key: 'Mobile App', value: 'Mobile App', flag: 'Mobile App', text: 'Mobile App' } ,
                    { key: 'Video', value: 'Video', flag: 'Video', text: 'Video' } ]

class HostPlatform extends Component{
    constructor(props){
        super(props)
        this.state = {
            PlatformName: '',
            URL: '',
            type: '',
            AccId: this.props.accid,
            PostSuc: false
        }
    }
    typeSelect = (e, { value }) => this.setState({type: value})

    onNameChange = (event) => {
        this.setState({PlatformName: event.target.value})
    }

    onURLChange = (event) => {
        this.setState({URL: event.target.value})
    }

    onSubmit(){
        fetch('http://localhost:5000/host',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify(this.state)
        })
        .then(response => response.json())
        .then( data => this.setState({PostSuc: true}))
    }
    render(){
        return(
            <div className='mh7'>
                <h3>Host a platform</h3>
                <Input className='mt3 mb3' 
                    onChange={this.onNameChange}
                    fluid iconPosition='left' 
                    placeholder='Enter Name of your platform..'>
                    <Icon name='computer' />
                    <input/>
                </Input>
                <Input className='mt3 mv3' 
                    onChange={this.onURLChange}
                    fluid iconPosition='left' 
                    placeholder='Enter URL of the platform...'>
                    <Icon name='globe' />
                    <input/>
                </Input>
                <Dropdown placeholder='Select Platform Type' fluid selection options={Options} onChange={this.typeSelect}/>
                <Checkbox className='mb3 mt4' label='I have read the Terms & Conditions.' />
                <Button color='blue' fluid 
                    className='ma4'
                    onClick={() => this.onSubmit()}
                    >Host your platform!
                </Button>

                {this.state.PostSuc ? <Message success header='Your platform has been hosted!' content="Ad providers can now view your platform!" /> : null}
            </div>
        );
    }
}

export default HostPlatform
import React, { Component } from 'react';
import PlatformCardList from './PlatformCardList'


class YourPlatforms extends Component{
    constructor(){
        super()
        this.state = {
            data: []
        }
    }

    getPlatforms(){
        fetch('http://localhost:5000/getplatforms',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                AccId : this.props.accid
            })
        })
        .then( response => response.json())
        .then(data => {
            this.setState({data: data})
        })
    }

    renderComponent(){
        if (this.state.data.length===0){
            return(
                <div className='mv4 mv5'>
                    <h2>:(</h2>
                    <p className='fw2 f5'>You have not hosted any platforms yet!</p>
                </div>
            );
            }
        else {
            return <PlatformCardList data={this.state.data} refresh={this.getPlatforms()}/>
        }
    }

    componentDidMount(){
        this.getPlatforms()
    }
    render(){
        return(
            <div className='mh3'>
                <h3>Your platforms</h3>
                {this.renderComponent()}
            </div>
        );
    }
}

export default YourPlatforms
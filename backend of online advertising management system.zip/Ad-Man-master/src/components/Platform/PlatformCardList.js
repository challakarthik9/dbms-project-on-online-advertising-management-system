import React, { Component } from 'react';
import PlatformCards from './PlatformCards'

class CardList extends Component{
    render(){
        const cardList = this.props.data.map((obj,i) => {
            return <PlatformCards name={obj.platform_name} url={obj.platformurl} type={obj.platformtype} platformid={obj.platformid} refresh={this.props.refresh}/>
        })
        return(
                <div className='flex flex-column items-center'>
                    {cardList}
                </div>
        );
    }
}

export default CardList
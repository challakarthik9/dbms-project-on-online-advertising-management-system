import React, { Component } from 'react';
import { Menu, Segment} from 'semantic-ui-react'
import HostPlatform from './HostPlatform'
import YourPlatforms from './YourPlatforms'

class Platform extends Component{
    constructor(){
        super()
        this.state = { activeItem: 'Host a platform' }
    }

    handleItemClick = (e, { name }) => this.setState({ activeItem: name })
    
    renderSegment(){
        if (this.state.activeItem === 'Host a platform') {
            return (
                <HostPlatform accid={this.props.accid}/>
            );
            }
        if (this.state.activeItem === 'Your Platforms'){
            return(
                <YourPlatforms accid={this.props.accid}/>
            );
        }
    }

    render(){
        const { activeItem } = this.state
        return(
            <div className='mh6 mt3'>
                <h2>Manage your platforms</h2>
                <Menu attached='top' tabular>
                    <Menu.Item name='Host a platform' active={activeItem === 'Host a platform'} onClick={this.handleItemClick} />
                    <Menu.Item name='Your Platforms' active={activeItem === 'Your Platforms'} onClick={this.handleItemClick} />
                    <Menu.Menu position='right'>
                    </Menu.Menu>
                </Menu>
                <Segment attached='bottom'>
                    {this.renderSegment()}
                </Segment>
            </div>
            
        );
    }
}

export default Platform
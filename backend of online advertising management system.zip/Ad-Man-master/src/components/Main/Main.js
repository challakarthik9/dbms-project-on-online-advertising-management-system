import React, { Component } from 'react';
import Nav from '../Nav/Nav'
import {BrowserRouter as Router, Route} from 'react-router-dom';
import Profile from '../Profile/Profile'
import Ads from '../Ads/Ads'
import Platform from '../Platform/Platform'
import MainAds from '../ShowAds/MainAds';



class Main extends Component{
    constructor(){
        super()
        this.state = {
          Email: '',
          FirstName: '',
          LastName: '',
          AccID:'',
          PhoneNumber: '',
          DateOfBirth: ''
        }
    }

    getUserDetails = () => {
      this.setState({Email : this.props.email})
      fetch('http://localhost:5000/getdetails',{
        method: 'post',
        headers: {'Content-type':'application/json'},
        body: JSON.stringify({
          Email: this.props.email
      })
    })
    .then(response => response.json())
    .then( data => {
      this.setState({
        Email: data[0].email,
        FirstName: data[0].fname,
        LastName: data[0].lname,
        PhoneNumber: data[0].phonenumber,
        AccID: data[0].accid,
        DateOfBirth: data[0].dataofbirth
      })
    })
    }

    componentWillMount(){
      this.getUserDetails()
    }

    render(){
        return(
          <Router>
            <div>
              <Nav name={this.state.FirstName}/>

              <Route path='/profile' component = { () => <Profile
              firstname={this.state.FirstName}
              lastname={this.state.LastName}
              phonenumber={this.state.PhoneNumber}
              email={this.state.Email}
              accid={this.state.AccID}
              />}></Route>

              <Route path='/manage-ads' component = {() => <Ads accid={this.state.AccID}/>}/>
              <Route path='/manage-platforms' component = {() => <Platform accid={this.state.AccID}/>}/>
              <Route path='/ads' component = {() => <MainAds accid={this.state.AccID}/>}/>
            </div>
          </Router> 
          
        );
    }
}

export default Main
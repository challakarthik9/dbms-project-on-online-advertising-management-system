import React, { Component } from 'react';
import { Dropdown, Menu, Input } from 'semantic-ui-react'
import {Link, NavLink} from 'react-router-dom';
import './Nav.css'


class Nav extends Component{
    constructor(props){
        super(props)
        this.state = {
          activeItem : 'home',
        }
    }


    handleItemClick = (e, { name }) => this.setState({ activeItem: name })

    render(){
        const { activeItem } = this.state

        return( 
        <div className='pa2 shadow-1 blue'>
        <Menu inverted secondary>
        <Menu.Item name='home' active={activeItem === 'home'} onClick={this.handleItemClick} />
        <Menu.Item
          name='Requests'
          active={activeItem === 'Requests'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          name='Ads'
          active={activeItem === 'Ads'}
          onClick={this.handleItemClick}  
        ><NavLink to='/ads'>Ads</NavLink></Menu.Item>
        <Menu.Item
          name='About us'
          active={activeItem === 'friends'}
          onClick={this.handleItemClick}
        />
        <Menu.Menu position='right'>
          <Menu.Item>
            <Input icon='search' placeholder='Search...' />
          </Menu.Item>
          <Dropdown item text={`Hello, ${this.props.name}`}>
            <Dropdown.Menu>
              <Dropdown.Item><Link to='/profile'><p className='black'>My Profile</p></Link></Dropdown.Item>
              <Dropdown.Item><Link to='/manage-ads'><p className='black'>Manage ads</p></Link></Dropdown.Item>
              <Dropdown.Item><Link to='/manage-platforms'><p className='black'>Manage Platforms</p></Link></Dropdown.Item>
              <Dropdown.Item href='/'><strong>Sign Out</strong></Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </Menu.Menu>
      </Menu>
        </div>

        );
    }
}

export default Nav
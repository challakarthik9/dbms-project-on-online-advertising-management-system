import React, { Component } from 'react';
import { Card, Button } from 'semantic-ui-react'

class AdCards extends Component{

    deleteAd(){
        const AdID = this.props.adid

        fetch('http://localhost:5000/deletead',{
            method: 'put',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                AdId : AdID
            })
        })
        .then(response => response.json())
        .then(data => {
            this.props.refresh()
        })
    }

    render(){
        return(
            <Card>
                <Card.Content>
                <Card.Header content={this.props.header} />
                <Card.Meta content={this.props.company}/>
                <Card.Description content={this.props.desc}/>
                </Card.Content>
                <Card.Content extra>
                    <div>
                    <Button basic color='red' onClick={() => this.deleteAd()}>
                        Remove Ad
                    </Button>
                    </div>
                </Card.Content>
            </Card>
        );
    }
}

export default AdCards;
import React, { Component } from 'react';
import { Input, Icon,TextArea, Form, Popup, Button, Checkbox, Message } from 'semantic-ui-react'

class PostAd extends Component{
    constructor(props){
    super(props)
    this.state = {
        AccId : this.props.accid,
        AdTitle : '',
        CompanyName : '',
        Desc : '',
        PostSuc : false
    }
    }

    onTitleChange = (event) => {
        console.log(event.target)
        this.setState({AdTitle: event.target.value})
    }
    onDescChange = (event) => {
        this.setState({Desc: event.target.value})
        
    }
    onCompChange = (event) => {
        this.setState({CompanyName: event.target.value})
    }
    onSubmit = () => {
        fetch('http://localhost:5000/postad',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify(this.state)
        })
        .then( response => response.json())
        .then(data =>  {
            if (data==='succ') {
                this.setState({PostSuc : true})
            }
        })
    }
    clearItems(){

    }
    render(){
        return(
            <div className='mh7'>
                <h3>Post an Advertisement</h3>
                <Input className='mt3 mb3'
                    onChange = {this.onTitleChange} 
                    fluid iconPosition='left' 
                    placeholder='Enter the title of your ad..'>
                    <Icon name='idea' />
                    <input/>
                </Input>
                <Input className='mt3 mv3' 
                    fluid iconPosition='left' 
                    placeholder={'Your company\' name'}
                    onChange={this.onCompChange}>
                    <Icon name='building' />
                    <input/>
                </Input>
                <Form className='mb3'><TextArea autoHeight onChange={this.onDescChange}  placeholder='Write a description for your ad..' /></Form>
                <Popup
                    
                    trigger={<Button icon='add' fluid content='Add pictures and graphics' />}
                    content='These will be displayed on your ad.'
                    on='hover'/>
                
                <Checkbox className='mb3 mt4' label='I have read the Terms & Conditions.' />
                <Button color='blue' fluid 
                    className='ma4'
                    onClick={() => this.onSubmit()}>Post this Ad!
                </Button>
                {this.state.PostSuc ? <Message success header='Your ad has been posted!' content="Hosts can now view your ads!" /> : null}
            </div>


        );
    }
}

export default PostAd
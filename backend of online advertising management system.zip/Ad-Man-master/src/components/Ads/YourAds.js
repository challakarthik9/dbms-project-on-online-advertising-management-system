import React, { Component } from 'react';
import CardList from './CardList' 

class YourAds extends Component{
    constructor(){
        super()
        this.state = {
            data: []
        }
    }

    getAds(){
        fetch('http://localhost:5000/getads',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                AccId : this.props.accid
            })
        })
        .then(response => response.json())
        .then(data => {
            this.setState({data: data})
        })
    }

    renderComponent(){
        if (this.state.data.length===0){
            return(
                <div className='mv4 mv5'>
                    <h2>:(</h2>
                    <p className='fw2 f5'>You have not posted any ads yet!</p>
                </div>
            );
            }
        else {
            return <CardList data={this.state.data} refresh={this.getAds()}/>
        }
    }
    componentDidMount(){
        this.getAds()
    }
    render(){
        return(
            <div className='mh3'>
                <h3>Your advertisements</h3>
                {this.renderComponent()}
            </div>
        );
    }
}

export default YourAds
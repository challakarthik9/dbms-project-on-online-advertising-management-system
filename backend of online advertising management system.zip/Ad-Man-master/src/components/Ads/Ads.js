import React, { Component } from 'react';
import { Input, Menu, Segment} from 'semantic-ui-react'
import PostAd from './PostAd'
import YourAds from './YourAds'

class Ads extends Component{
    constructor(){
        super()
        this.state = { activeItem: 'Post an Ad' }
    }

    handleItemClick = (e, { name }) => this.setState({ activeItem: name })

    renderSegment(){
        if (this.state.activeItem === 'Post an Ad') {
            return (
                <PostAd accid={this.props.accid}/>
            );
        }

        if (this.state.activeItem === 'Your Ads'){
            return(
                <YourAds accid={this.props.accid}/>
            );
        }
    }
    render(){
        const { activeItem } = this.state
        return(
            <div className='mh6 mt3'>
                        <h2>Manage your advertisements</h2>
                        <Menu attached='top' tabular>
                            <Menu.Item name='Post an Ad' active={activeItem === 'Post an Ad'} onClick={this.handleItemClick} />
                            <Menu.Item
                                name='Your Ads'
                                active={activeItem === 'Your Ads'}
                                onClick={this.handleItemClick}
                            />
                            <Menu.Menu position='right'>
                                <Menu.Item>
                                <Input
                                    transparent
                                    icon={{ name: 'search', link: true }}
                                    placeholder='Search ads...'
                                />
                                </Menu.Item>
                            </Menu.Menu>
                        </Menu>

                        <Segment attached='bottom'>
                            {this.renderSegment()}
                        </Segment>
            </div>
        );
    }
}

export default Ads;
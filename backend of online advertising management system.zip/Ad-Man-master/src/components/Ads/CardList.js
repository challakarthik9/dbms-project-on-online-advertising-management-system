import React, { Component } from 'react';
import AdCards from './AdCards'

class CardList extends Component{
    render(){
        const cardList = this.props.data.map((obj,i) => {
            return <AdCards header={obj.adtitle} company={obj.company} desc={obj.description} adid={obj.adid} refresh={this.props.refresh}/>
        })
        return(
                <div className='flex flex-column items-center'>
                    {cardList}
                </div>
        );
    }
}

export default CardList
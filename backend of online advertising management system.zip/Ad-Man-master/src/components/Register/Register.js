import React, { Component } from 'react';
import { Button, Divider,Input, Icon, Message} from 'semantic-ui-react'
import { DateInput } from 'semantic-ui-calendar-react';
import './Register.css';
import { Redirect } from 'react-router'


class Register extends Component{
    constructor(){
        super()
        this.state = {
            FirstName: '',
            LastName: '',
            Email: '',
            PhoneNumber: '',
            Password: '',
            ConfPassword: '',
            date:'1990-01-01',
            passmatch: true,
            anyEmpty: false,
            loading: false,
            signedup: false
        }
    }

    onFirstNameChange = (event) =>{
        this.setState({FirstName: event.target.value})
    }

    onLastNameChange = (event) =>{
        this.setState({LastName: event.target.value})
    }

    onEmailChange = (event) =>{
        this.setState({Email: event.target.value})
    }

    onPhoneChange = (event) =>{
        this.setState({PhoneNumber: event.target.value})
    }
    onPasswordChange = (event) =>{
        this.setState({Password: event.target.value})
        if (!(event.target.value === this.state.ConfPassword)) {
            this.setState({passmatch: false})
        }
        else {
            this.setState({passmatch: true})
        }
    }
    onConfPassChange = (event) =>{
        this.setState({ConfPassword: event.target.value})
        if (!(this.state.Password === event.target.value)) {
            this.setState({passmatch: false})
        }
        else {
            this.setState({passmatch: true})
        }
    }

    submitDetails = () => {

        this.setState({loading: true})
        if (this.state.passmatch === true && 
            this.state.FirstName.length > 0 &&
            this.state.LastName.length > 0 &&
            this.state.Email.length > 0 &&
            this.state.PhoneNumber.length > 0 &&
            this.state.Password.length > 0){
            this.setState({anyEmpty: false})
            fetch('http://localhost:5000/signup',{
                method: 'post',
                headers: {'Content-type':'application/json'},
                body: JSON.stringify({
                    FirstName: this.state.FirstName,
                    LastName: this.state.LastName,
                    Email: this.state.Email,
                    PhoneNumber: this.state.PhoneNumber,
                    date: this.state.date,
                    Password: this.state.Password
                })
            })
            .then(response => response.json())
            .then( data => {
                if (data=== 'succ') {
                    
                    this.setState({loading:false, signedup: true})
                    console.log('Signed up')
                    
                }
                else {
                    console.log('Error signing up!')
                }
            })
            .catch( err => { console.log('Error in backend')})
        }

        else {
            console.log(this.state.FirstName.length > 0)
            this.setState({anyEmpty: true})
        }
        this.setState({loading:false})
    }

    render(){
        if (this.state.signedup === true) {
            return(
                <Redirect to='/'/>
            );
        }

        else{
        return(
        <div className='dib shadow-1 pa4 ma4'>
            <p className='f4 fw6 ma4'>Sign Up Now!</p>
            <div>
                <div className='dib mr3'>
                        <Input onChange={this.onFirstNameChange} placeholder='First Name'>
                        <input />
                        </Input>
                </div>

                <div  className='dib'>
                    <Input placeholder='Last Name' onChange={this.onLastNameChange}>
                    <input />
                    </Input>
                </div>

                <Input className='mt3' 
                    onChange={this.onEmailChange} 
                    fluid iconPosition='left' 
                    placeholder='Email Address'>
                    <Icon name='at' />
                    <input/>
                </Input>

                <Input 
                    className='mt3' 
                    onChange={this.onPhoneChange} 
                    fluid iconPosition='left' 
                    type='number' placeholder='Phone Number'>
                    <Icon name='phone' />
                    <input/>
                </Input>

                <Input 
                    className='mt3' 
                    error={!(this.state.passmatch)} 
                    onChange={this.onPasswordChange} 
                    fluid iconPosition='left' type='password' 
                    placeholder='Password'>
                    <Icon name='lock' />
                    <input/>
                </Input>

                <Input className='mt3' 
                    error={!(this.state.passmatch)} 
                    onChange={this.onConfPassChange} 
                    fluid iconPosition='left' type='password' 
                    placeholder='Confirm Password'>
                    <Icon name='lock' />
                    <input/>
                </Input>

                <DateInput fluid className='mt3 mb4'
                name="date"
                placeholder="Enter DOB"
                iconPosition="left" />
                { this.state.anyEmpty ? 
                 <Message
                 error
                 header='Oops!'
                 content={'Seems like you haven\'t filled in all the values.'} 
               /> 
                : null}
                <Button color='blue' fluid onClick={this.submitDetails} 
                    loading={this.state.loading}
                    className='ma4'>Sign Up!
                </Button>
                <Divider horizontal className='divider-signup'>Or</Divider>
                <Button basic fluid color='blue' href='/' 
                content='Alrady have an account?' />
            </div>
            
        </div>
        );}
    }
}

export default Register;

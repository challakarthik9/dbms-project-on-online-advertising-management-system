import React, { Component } from 'react';
import { Pagination, Loader } from 'semantic-ui-react'
import AdCardList from './AdCardList'

class MainAds extends Component{
    constructor(){
        super()
        this.state = {
            ads : [],
            pages : 0,
            activePage: 1,
            loading: true
        }
    }

    handlePaginationChange = (e, { activePage }) => {
        this.setState({ activePage })   
    }

    getAllAds(){
        fetch('http://localhost:5000/getallads',{
            method: 'get',
            headers: {'Content-type':'application/json'}
        })
        .then(response => response.json())
        .then(data => {
            const n = data.length
            let n_pages = Math.ceil(n/6)
            if (n_pages === 0){
                n_pages = 1
            }
            this.setState({ads: data,pages: n_pages, loading: false})
        })
    }

    componentDidMount(){
        this.getAllAds()
    }
    render(){
        const start_index = (this.state.activePage*6)-6
        const end_index = (this.state.activePage*6)
        return(
            <div className='pa2'>
                <p className='f3 fw7 pt4'>Some great ads for you...</p>
                <div className='ma4 pa6 shadow-1'>
                    {
                        this.state.loading?
                        <Loader active content='Loading' /> :
                        <AdCardList data={this.state.ads.slice(start_index,end_index)} accid={this.props.accid}/>
                    }
                </div>
                <Pagination defaultActivePage={1} totalPages={this.state.pages} onPageChange={this.handlePaginationChange}/>
            </div>
        );
    }
}

export default MainAds

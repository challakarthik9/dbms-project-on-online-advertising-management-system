import React, { Component } from 'react';
import CardAds from './CardAds'

class AdCardList extends Component{
    render(){
        const { data } = this.props
        const cardList = data.map((obj,i) => {
            return <CardAds title={obj.adtitle} company={obj.company} desc={obj.description} adid={obj.adid} from_accid={this.props.accid} to_accid={obj.accid}/>
        })
        return(
                <div className='flex flex-column items-center'>
                    {cardList}
                </div>
        );
    }
}

export default AdCardList
import React, { Component } from 'react';
import { Card, Button, Message } from 'semantic-ui-react'

class CardAds extends Component{

    constructor(){
        super()
        this.state ={
            request_success: false,
            button_disable: false,
            button_text: 'Request'
        }
    }

    submitRequest(){
        const {from_accid,to_accid, adid} = this.props 
        fetch('http://localhost:5000/postrequest',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                from_accid: from_accid,
                to_accid: to_accid,
                to_adid : adid
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data==='succ'){
                this.setState({request_success: true})
            }
        })
        this.check()
    }

    check(){
        const {from_accid, to_accid, adid} = this.props;
        if(from_accid===to_accid){
            this.setState({button_disable: true})
        }

        fetch('http://localhost:5000/checkrequest',{
            method: 'post',
            headers: {'Content-type':'application/json'},
            body: JSON.stringify({
                from_accid: from_accid,
                to_accid: to_accid,
                to_adid : adid
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.length){
                this.setState({button_text: 'Awaiting Confirmation..',button_disable: true})
            }
        })
    }

    componentDidMount(){
        this.check()
    }
    render(){
        return(
            <Card fluid>
                <Card.Content>
                <Card.Header content={this.props.title} />
                <Card.Meta content={this.props.company}/>
                <Card.Description content={this.props.desc}/>
                {
                    this.state.request_success ?
                    <Message success header='Request Sent!' />:
                    null

                }
                
                </Card.Content>
                <Card.Content extra>
                    <div>
                    <Button basic color='green' disabled={this.state.button_disable}
                    onClick = {() => this.submitRequest()}>
                        {this.state.button_text}
                    </Button>
                    </div>
                </Card.Content>
                
            </Card>
        );
    }
}

export default CardAds
import React, { Component } from 'react';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';


class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
        <Switch>
          <Route exact path='/' component = { Login }></Route>
          <Route path='/signup' component = { Register }></Route>
        </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
